/* ===== EASY-TO-EDIT BUSINESS SETTINGS ===== */
const BUSINESS = {
  name: "Unique Style Beauty Saloon",
  whatsapp: "923060770077",
  phoneDisplay: "+92 306 0770077",
  generalMessage: "Hi Unique Style Beauty Saloon! I’d like to ask about your services, prices and available appointment timings.",
  hours: {
    Monday: "9:00 AM – 9:00 PM",
    Tuesday: "9:00 AM – 9:00 PM",
    Wednesday: "9:00 AM – 9:00 PM",
    Thursday: "9:00 AM – 9:00 PM",
    Friday: "9:00 AM – 9:00 PM",
    Saturday: "9:30 AM – 9:30 PM",
    Sunday: "9:00 AM – 9:00 PM"
  }
};

const waUrl = message => `https://wa.me/${BUSINESS.whatsapp}?text=${encodeURIComponent(message)}`;

document.querySelectorAll('.wa-general').forEach(link => link.href = waUrl(BUSINESS.generalMessage));
document.querySelectorAll('.service-wa').forEach(link => {
  const service = link.dataset.service;
  link.href = waUrl(`Hi Unique Style Beauty Saloon! I’m interested in ${service}. Please share the price and available timings.`);
});

const list = document.getElementById('hoursList');
const today = new Intl.DateTimeFormat('en-US', { weekday: 'long' }).format(new Date());
Object.entries(BUSINESS.hours).forEach(([day, hours]) => {
  const row = document.createElement('div');
  row.className = `hour-row ${day === today ? 'today' : ''}`;
  row.innerHTML = `<span>${day}${day === today ? ' • Today' : ''}</span><strong>${hours}</strong>`;
  list.appendChild(row);
});

document.getElementById('year').textContent = new Date().getFullYear();

const toggle = document.querySelector('.menu-toggle');
const nav = document.querySelector('.nav-links');
toggle.addEventListener('click', () => {
  nav.classList.toggle('open');
  toggle.setAttribute('aria-expanded', nav.classList.contains('open'));
});
document.querySelectorAll('.nav-links a').forEach(a => a.addEventListener('click', () => nav.classList.remove('open')));

const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => { if(entry.isIntersecting){ entry.target.classList.add('visible'); observer.unobserve(entry.target); } });
}, { threshold: .12 });
document.querySelectorAll('.reveal').forEach(el => observer.observe(el));
