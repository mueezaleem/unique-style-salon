UNIQUE STYLE BEAUTY SALOON — WEBSITE PACKAGE

Files:
- index.html
- styles.css
- script.js

Quick editing:
- Business phone / WhatsApp / opening hours: edit BUSINESS settings at the top of script.js
- Text/content: edit index.html
- Colors/layout: edit :root variables and sections in styles.css
- Gallery images: replace the image URLs in index.html with your own salon photos

Important:
- The supplied website uses editorial beauty images for presentation, not claimed as photos of the business.
- Service wording is intentionally general because only the categories Beauty Salon and Mehndi Designer were confirmed from the public listing.
- The WhatsApp number used is the current number returned by the Google business listing during build: +92 306 0770077.
- The map is centered on the Google listing coordinates.

Open index.html in any modern browser. No build process is required.
